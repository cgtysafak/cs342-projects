Cagatay SAFAK - 21902730 - Section 2
Ayse KELLECI - 21902532 - Section 2
